package com.cpt.payments.pojo.provider.response;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProviderServiceErrorResponse {

	private String errorCode;
	private String errorMessage;
	private HttpStatus httpStatus;
	private boolean tpProviderError;
	
}
