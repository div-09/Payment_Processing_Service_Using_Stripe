package com.cpt.payments.dao;

import com.cpt.payments.dto.TransactionLog;

public interface TransactionLogDao {
	public void createTransactionLog(TransactionLog transactionLog);
}
