package com.cpt.payments.pojo.stripe;

import lombok.Data;

@Data
public class StripeCheckoutSessionData {
	private StripeCheckoutSessionObject object;
}
