package com.cpt.payments.constants;

public class Endpoints {
	public static final String PAYMENTS ="/payments";
	public static final String STATUS_UPDATE = "/status";
	public static final String PROCESS_PAYMENT = "/process";
}
