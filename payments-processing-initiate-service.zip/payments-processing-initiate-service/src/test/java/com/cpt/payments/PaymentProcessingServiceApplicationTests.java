package com.cpt.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentProcessingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
